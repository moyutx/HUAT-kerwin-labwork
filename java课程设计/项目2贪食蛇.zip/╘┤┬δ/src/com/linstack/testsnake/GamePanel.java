package com.linstack.testsnake;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


public class GamePanel extends JPanel { //游戏面板类，继承自Jpanel面板类
    //属性：
    private int snakeLength; //蛇的初始长度
    private String direction; //蛇运动方向
    private int[] snakeX = new int[200]; //蛇运动的X坐标，初始值为200
    private int[] snakeY = new int[200]; //蛇运动的Y坐标，初始值为200
    private boolean isStart = false; //游戏运行状态，初始为关
    private Timer timer; //加入一个定时器
    private int foodX; //食物x坐标
    private int foodY; //食物y坐标
    private int score; //定义得分
    private boolean isDead = false; //定义蛇的存活状态

    //初始化坐标
    private void init(){
        //定义蛇的初始长度
        snakeLength = 3;
        //初始化蛇头方向
        direction = "R"; //U上，D下，L左，R右
        //初始化snake各部位的坐标
        snakeX[0] = 175; //初始头部坐标，图片的像素尺寸是25*25px
        snakeY[0] = 275;
        snakeX[1] = 150; //初始身体坐标
        snakeY[1] = 275;
        snakeX[2] = 125; //初始尾部坐标
        snakeY[2] = 275;
        //初始化食物的坐标
        foodX = 300;
        foodY = 200;
        //初始化得分：
        score = 0;
    }

    //定义构造器
    GamePanel() {
        init();
        //将焦点定位在当前操作的面板上
        this.setFocusable(true);
        //加入监控
        this.addKeyListener(new KeyAdapter(){
            @Override
            public void keyPressed(KeyEvent e) { //监听键盘按下操作
                super.keyPressed(e);
                int keyCode = e.getKeyCode(); //获取键盘按下时对应的ASCII码
                if (keyCode == KeyEvent.VK_SPACE){
                    if (isDead){
                        //小蛇死亡的情况下，恢复初始状态
                        init();
                        isDead = false;
                    }else {
                        isStart = !isStart; //监听到空格键后，将运行状态取反
                        repaint(); //重复画板内容
                    }
                }
                //监听上下左右按键的内容
                if (keyCode == KeyEvent.VK_UP){
                    direction = "U";
                }
                if (keyCode == KeyEvent.VK_DOWN){
                    direction = "D";
                }
                if (keyCode == KeyEvent.VK_LEFT){
                    direction = "L";
                }
                if (keyCode == KeyEvent.VK_RIGHT){
                    direction = "R";
                }
            }
        });
        //对定时器进行初始化操作
        timer = new Timer(100, new ActionListener() {
            /*
            * ActionListener:事件监听
            * 具体动作在actionPerformed中实现 */
            @Override
            public void actionPerformed(ActionEvent e) {
                if (isStart && !isDead){ //判定开始且小蛇没有死亡的情况下走下面分支
                    //游戏开始，蛇的身体向前移动
                    for (int i = snakeLength-1; i > 0; i--) {
                        //蛇身的移动
                        snakeX[i] = snakeX[i-1];
                        snakeY[i] = snakeY[i-1];
                    }
                    //蛇头的移动
                    if ("R".equals(direction)){
                        snakeX[0] += 25; //向右移动25px
                    }
                    if ("L".equals(direction)){
                        snakeX[0] -= 25; //向左移动25px
                    }
                    if ("U".equals(direction)){
                        snakeY[0] -= 25; //向上移动25px
                    }
                    if ("D".equals(direction)){
                        snakeY[0] += 25; //向下移动25px
                    }
                    //防止蛇飞出边界
                    if (snakeX[0] > 750){
                        snakeX[0] = 25; //防止超出右边界
                    }
                    if (snakeX[0] < 25){
                        snakeX[0] = 750; //防止超出左边界
                    }
                    if (snakeY[0] > 750){
                        snakeY[0] = 150; //防止超出下边界
                    }
                    if (snakeY[0] < 150){
                        snakeY[0] = 750; //防止超出上边界
                    }
                    //检测食物与蛇头碰撞，模拟吃食物得分的过程
                    if (snakeX[0]==foodX&&snakeY[0]==foodY){
                        //蛇长度加1:
                        snakeLength++;
                        /*食物碰撞后，随机在网格内生成
                        * 食物坐标随机改变(需要符合网格规则，当前网格范围：X[25，750]，Y[150，750])
                        * 食物X坐标[25,750]：
                        *  [25,750]/25 = [1,30]
                        *  [1,30]的来源
                        *  Math.random()              ->  [0.0,1.0)
                        *  (int)(Math.random()*30)    ->  [0,30)    ->[0,29]
                        *  (int)(Math.random()*30)+1  ->  [1,30]                        *
                        * 食物Y坐标[150，750]:
                        *  [150，750]/25 = [6,30]
                        *  [6,30]的来源
                        *  Math.random()              ->  [0.0,1.0)
                        *  (int)(Math.random()*25)    ->  [0,25)    ->[0,24]
                        *  (int)(Math.random()*25)+6  ->  [6,30]
                        * */
                        foodX = (int)(Math.random()*30+1)*25; //X[25，750]
                        foodY = (int)(Math.random()*25+6)*25; //Y[150，750]
                        score += 10; //得分+10分
                    }
                    //死亡状态：蛇头与任一身体部分相撞则死亡
                    for (int i = 1; i < snakeLength; i++) {
                        if (snakeX[0] == snakeX[i] && snakeY[0] == snakeY[i]) {
                            isDead = true;
                            break;
                        }
                    }
                    repaint(); //重新绘制蛇
                }
            }
        });
        //定时器启动
        timer.start();
    }

    /*重写paintComponent方法
    * paintComponent是虚拟机底层方法
    * */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        //填充背景颜色
        this.setBackground(new Color(254, 255, 179));
        //画头部（宽780*高140px）的标题图片（四个参数：当前面板，画笔，画板左上角x坐标，画板左上角y坐标）
        Images.headerIMG.paintIcon(this,g,10,10);
        //调整画笔颜色并填充矩形
        g.setColor(new Color(231, 255, 245));
        g.fillRect(10,150,780,610);
        //画蛇，蛇头根据方向进行变更
        if ("R".equals(direction)){
            Images.rightIMG.paintIcon(this,g,snakeX[0],snakeY[0]);
        }
        if ("L".equals(direction)){
            Images.leftIMG.paintIcon(this,g,snakeX[0],snakeY[0]);
        }
        if ("U".equals(direction)){
            Images.upIMG.paintIcon(this,g,snakeX[0],snakeY[0]);
        }
        if ("D".equals(direction)){
            Images.downIMG.paintIcon(this,g,snakeX[0],snakeY[0]);
        }
        /*Images.bodyIMG.paintIcon(this,g,snakeX[1],snakeY[1]);
        Images.bodyIMG.paintIcon(this,g,snakeX[2],snakeY[2]);*/
        //优化蛇身，便于后续得分加长
        for (int i = 1; i < snakeLength; i++) {
            Images.bodyIMG.paintIcon(this,g,snakeX[i],snakeY[i]);
        }
        //根据游戏初始状态设置提示语
        if (!isStart){
            //画一个提示语
            g.setColor(new Color(0, 0, 0, 253)); //设置画笔颜色
            g.setFont(new Font("微软雅黑",Font.BOLD,40)); //设置画笔字体格式（三个参数：字体，加粗，字号）
            g.drawString("点击空格开始游戏",250,350);
        }
        //画食物
        Images.foodIMG.paintIcon(this,g,foodX,foodY);
        //画得分面板
        g.setColor(new Color(11, 67, 255)); //设置画笔颜色
        g.setFont(new Font("微软雅黑",Font.BOLD,20)); //设置画笔字体格式（三个参数：字体，加粗，字号）
        g.drawString("积分："+score,680,40);
        //画死亡状态
        if (isDead){
            g.setColor(new Color(255, 131, 85)); //设置画笔颜色
            g.setFont(new Font("微软雅黑",Font.BOLD,20)); //设置画笔字体格式（三个参数：字体，加粗，字号）
            g.drawString("小蛇死亡，游戏结束！本局游戏得分："+score,180,400);
            g.drawString("按下空格键重新开始游戏！",220,430);
        }
    }
}
