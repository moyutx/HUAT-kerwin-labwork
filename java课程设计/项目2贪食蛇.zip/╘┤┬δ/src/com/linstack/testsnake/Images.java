package com.linstack.testsnake;


import javax.swing.*;
import java.net.URL;


class Images {
    //图片类对象，操作对象来实现对包内的图片进行利用

    //封装图片保存的路径成一个url对象，利用反射将图片路径转为一个url信息
    private static URL bodyURL = Images.class.getResource("/images/body.png"); //身体
    private static URL upURL = Images.class.getResource("/images/headup.png"); //头向上
    private static URL downURL = Images.class.getResource("/images/headdown.png"); //头向下
    private static URL leftURL = Images.class.getResource("/images/headleft.png"); //头向左
    private static URL rightURL = Images.class.getResource("/images/headright.png"); //头向右
    private static URL headerURL = Images.class.getResource("/images/header.png"); //标题
    private static URL foodURL = Images.class.getResource("/images/food.png"); //食物
    //将获取的url信息传入图标对象中用作后续使用
    static ImageIcon bodyIMG = new ImageIcon(bodyURL); //静态修饰方便后续直接调用
    static ImageIcon upIMG = new ImageIcon(upURL);
    static ImageIcon downIMG = new ImageIcon(downURL);
    static ImageIcon leftIMG = new ImageIcon(leftURL);
    static ImageIcon rightIMG = new ImageIcon(rightURL);
    static ImageIcon headerIMG = new ImageIcon(headerURL);
    static ImageIcon foodIMG = new ImageIcon(foodURL);

}