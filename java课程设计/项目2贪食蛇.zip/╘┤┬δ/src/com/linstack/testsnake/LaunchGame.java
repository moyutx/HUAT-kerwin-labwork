package com.linstack.testsnake;

import javax.swing.*;
import java.awt.*;


public class LaunchGame {
    public static void main(String[] args) {
        //创建一个窗体
        JFrame jf = new JFrame();
        //给窗体设置标题
        jf.setTitle("小游戏，大逻辑 by 东方瑞通");
        //设置窗体弹出的坐标以及窗体自身的宽高
        int width = Toolkit.getDefaultToolkit().getScreenSize().width;
        int height = Toolkit.getDefaultToolkit().getScreenSize().height;
        jf.setBounds((width-800)/2,(height-800)/2,800,800);
        //窗体的位置及大小不可变更
        jf.setResizable(false);
        //窗口关闭同步程序关闭
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //创建面板并添加到窗体中
        GamePanel gp = new GamePanel();
        jf.add(gp);
        //窗体的显示展示(此显示最好在窗体代码最下端，方便上述设置做变更)
        jf.setVisible(true);
    }
}
