package com.sxt;

import java.awt.*;

public class GameUtils {
    //背景图
    public static Image bgimg = Toolkit.getDefaultToolkit().createImage("images/sea.jpg");


}
