package com.sxt;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class GameUtils {


    //敌方鱼类集合
    public static List<Enamy>EnamyList = new ArrayList<>();


    //背景图
    public static Image bgimg = Toolkit.getDefaultToolkit().createImage("images/sea.jpg");

    //敌方鱼类
    public static Image enamy1_img = Toolkit.getDefaultToolkit().createImage("images/enemyFish/fish1_r.gif");




}
