package com.sxt;

import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GameWin extends JFrame {

    /** 游戏状态 0未开始,1游戏中,2通关失败,3通关成功,4暂停,5重新开始*/

    //定义游戏默认状态
    public int state = 0;

    Image offScreenImage;

    //宽高
    int width = 1440;
    int height = 900;

    double random;
    //计数器
    int time = 0;

    //背景
    Bg bg = new Bg();

    //敌方鱼类
    Enamy enamy ;



    public void launch(){
        this.setVisible(true);
        this.setSize(width,height);
        this.setLocationRelativeTo(null);
        //this.setResizable(false);
        this.setTitle("瑞通大鱼吃小鱼");
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (e.getButton()==1&&state==0){
                    state=1;
                    repaint();
                }
            }
        });



        while (true){
            repaint();
            time++;
            try {
                Thread.sleep(40);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void paint(Graphics g) {
        //懒加载模式初始化对象
        offScreenImage = createImage(width,height);
        Graphics gImage = offScreenImage.getGraphics();
        g.drawImage(GameUtils.bgimg,0,0,null);

        switch (state){
            case 0:
                gImage.drawImage(GameUtils.bgimg,0,0,null);
                gImage.setColor(Color.pink);
                gImage.setFont(new Font("仿宋",Font.BOLD,80));
                gImage.drawString("开始",700,500);
                break;
            case 1:
                bg.paintSelf(gImage);
                logic();
                for (Enamy enamy:GameUtils.EnamyList) {
                    enamy.paintSelf(gImage);
                }
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
                default:
        }

        g.drawImage(offScreenImage,0,0,null);

    }





    void logic(){
        //敌方鱼生成
        if (time%10==0) {
            enamy = new Enamy_1_L();
            GameUtils.EnamyList.add(enamy);
        }
        //移动方向
        for (Enamy enamy:GameUtils.EnamyList){
            enamy.x = enamy.x+enamy.dir*enamy.speed;
        }

    }




    public static void main(String[] args) {
        GameWin gameWin = new GameWin();
        gameWin.launch();
    }
}
