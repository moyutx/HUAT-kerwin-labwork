package com.sxt;

import java.awt.*;

public class Bg {
    void paintSelf(Graphics g){
        g.drawImage(GameUtils.bgimg,0,0,null);
    }
}
