package com.sxt;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GameWin extends JFrame {

    /** 游戏状态 0未开始,1游戏中,2通关失败,3通关成功,4暂停,5重新开始*/
    //定义游戏默认状态
    public int state = 0;
    //宽高
    int width = 1440;
    int height = 900;

    Bg bg = new Bg();

    public void launch(){
        this.setVisible(true);
        this.setSize(width,height);
        this.setLocationRelativeTo(null);
        //this.setResizable(false);
        this.setTitle("瑞通大鱼吃小鱼");
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (e.getButton()==1&&state==0){
                    state=1;
                    repaint();
                }
            }
        });


        while (true){
            repaint();
            try {
                Thread.sleep(40);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void paint(Graphics g) {
        g.drawImage(GameUtils.bgimg,0,0,null);

        switch (state){
            case 0:
                g.drawImage(GameUtils.bgimg,0,0,null);
                g.setColor(Color.pink);
                g.setFont(new Font("仿宋",Font.BOLD,80));
                g.drawString("开始",700,500);
                break;
            case 1:
                bg.paintSelf(g);
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
                default:
        }
    }

    public static void main(String[] args) {
        GameWin gameWin = new GameWin();
        gameWin.launch();
    }
}
