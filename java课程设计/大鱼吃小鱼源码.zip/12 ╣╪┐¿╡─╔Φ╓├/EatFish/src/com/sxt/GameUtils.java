package com.sxt;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class GameUtils {

    //方向
    static boolean UP =false;
    static boolean DOWN =false;
    static boolean LEFT =false;
    static boolean RIGHT =false;

    //分数
    static int count = 0;
    //关卡等级
    static int level = 0;

    //敌方鱼类集合
    public static List<Enamy> EnamyList = new ArrayList<>();


    //背景图
    public static Image bgimg = Toolkit.getDefaultToolkit().createImage("images/sea.jpg");

    //敌方鱼类
    public static Image enamy1_img = Toolkit.getDefaultToolkit().createImage("images/enemyFish/fish1_r.gif");


    //我方鱼类
    public static Image MyFishimg_L = Toolkit.getDefaultToolkit().createImage("images/myFish/myfish_left.gif");
    public static Image MyFishimg_R = Toolkit.getDefaultToolkit().createImage("images/myFish/myfish_right.gif");



}
