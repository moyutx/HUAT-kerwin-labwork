package com.sxt;

import java.awt.*;

public class Enamy {
    //定义图片
    Image img;
    //定义物体坐标
    int x;
    int y;
    int width;
    int height;
    //移动速度
    int speed;
    //方向
    int dir = 1;
    //类型
    int type;
    //分值
    int count;
    //绘制自身方法
    public void paintSelf(Graphics g){
        g.drawImage(img,x,y,width,height,null);
    }
    //获取自身矩形用于碰撞检测
    public Rectangle getRec(){
        return new Rectangle(x,y,width,height);
    }
}

//敌方鱼左类
class Enamy_1_L extends Enamy{
    Enamy_1_L(){
        this.x = -45;
        this.y = (int)(Math.random()*700+100);
        this.width = 45;
        this.height = 69;
        this.speed = 10;
        this.count = 1;
        this.type = 1;
        this.img = GameUtils.enamy1_img;
    }
}
