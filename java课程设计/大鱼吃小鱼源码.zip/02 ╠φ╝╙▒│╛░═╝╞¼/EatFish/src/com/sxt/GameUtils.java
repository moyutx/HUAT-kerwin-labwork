package com.sxt;

import java.awt.*;

public class GameUtils {
    public static Image bgimg = Toolkit.getDefaultToolkit().createImage("images/sea.jpg");
}
