package com.sxt;

import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GameWin extends JFrame {

    /** 游戏状态 0未开始,1游戏中,2通关失败,3通关成功,4暂停,5重新开始*/

    //定义游戏默认状态
    static int state = 0;

    Image offScreenImage;

    //宽高
    int width = 1440;
    int height = 900;

    double random;
    //计数器
    int time = 0;

    //背景
    Bg bg = new Bg();

    //敌方鱼类
    Enamy enamy;

    //我方鱼类
    MyFish myFish = new MyFish();


    public void launch(){
        this.setVisible(true);
        this.setSize(width,height);
        this.setLocationRelativeTo(null);
        //this.setResizable(false);
        this.setTitle("瑞通大鱼吃小鱼");
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (e.getButton()==1&&state==0){
                    state=1;
                    repaint();
                }
            }
        });

        //键盘移动
        this.addKeyListener(new KeyAdapter() {
            @Override//按压
            public void keyPressed(KeyEvent e) {
                super.keyPressed(e);
                //WASD
                if (e.getKeyCode()==87){
                    GameUtils.UP = true;
                }
                if (e.getKeyCode()==83){
                    GameUtils.DOWN = true;
                }
                if (e.getKeyCode()==65){
                    GameUtils.LEFT = true;
                }
                if (e.getKeyCode()==68){
                    GameUtils.RIGHT = true;
                }
            }

            @Override//抬起
            public void keyReleased(KeyEvent e){
                super.keyReleased(e);
                if (e.getKeyCode()==87){
                    GameUtils.UP = false;
                }
                if (e.getKeyCode()==83){
                    GameUtils.DOWN = false;
                }
                if (e.getKeyCode()==65){
                    GameUtils.LEFT = false;
                }
                if (e.getKeyCode()==68){
                    GameUtils.RIGHT = false;
                }
            }
        });


        while (true){
            repaint();
            time++;
            try {
                Thread.sleep(40);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void paint(Graphics g) {
        //懒加载模式初始化对象
        offScreenImage = createImage(width,height);
        Graphics gImage = offScreenImage.getGraphics();
        bg.paintSelf(gImage , myFish.level);

        switch (state){
            case 0:

                break;
            case 1:

                myFish.paintSelf(gImage);
                logic();
                for (Enamy enamy:GameUtils.EnamyList) {
                    enamy.paintSelf(gImage);
                }
                break;
            case 2:
                break;
            case 3:
                myFish.paintSelf(gImage);
                break;
            case 4:
                break;
                default:
        }

        g.drawImage(offScreenImage,0,0,null);

    }



    void logic(){
        //关卡难度
        if (GameUtils.count<5){
            GameUtils.level = 0;
            myFish.level = 1;
        }else if (GameUtils.count<=15){
            GameUtils.level = 1;
        }else if (GameUtils.count<=50){
            GameUtils.level = 2;
            myFish.level = 2;
        }else if (GameUtils.count<=150){
            GameUtils.level = 3;
            myFish.level = 3;
        }else if (GameUtils.count<=300){
            GameUtils.level = 4;
            myFish.level = 3;
        }else if (GameUtils.count>300){
            state = 3;
        }



        if (time%10==0) {
            enamy = new Enamy_1_L();
            GameUtils.EnamyList.add(enamy);
        }
        for (Enamy enamy:GameUtils.EnamyList){
            enamy.x = enamy.x+enamy.dir*enamy.speed;

            //我方鱼与敌方鱼碰撞检测
            if (myFish.getRec().intersects(enamy.getRec())){
                System.out.println("碰撞了");
                enamy.x = -200;
                enamy.y = -200;
                GameUtils.count = GameUtils.count+enamy.count;
            }
        }
    }

    public static void main(String[] args) {
        GameWin gameWin = new GameWin();
        gameWin.launch();
    }
}
