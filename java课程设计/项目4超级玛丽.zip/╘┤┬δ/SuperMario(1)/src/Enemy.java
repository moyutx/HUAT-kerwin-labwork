
//我们保证独立完成了整个程序从分析、设计到编码的所有工作。
//本段代码编写<202131773330-赖杰>
import java.awt.image.BufferedImage;

public class Enemy implements Runnable {
    //    存储当前坐标
    private int x, y;
    //    存储敌人类型
    private int type;
    //    判断敌人运动方向
    private boolean face_to = true;
    //    用于显示敌人的当前图像
    private BufferedImage show;
    //    定义一个背景图像
    private BackGround bg;
    //    食人花运动的极限范围
    private int max_up = 0;
    private int max_down = 0;
    //    定义线程对象
    private Thread thread = new Thread(this);
    //    定义当前的图片的状态
    private int image_type = 0;
    //判断光束出现的时间
    private int time_to = 0;
    //判断光束是否消失
    private boolean vanish = false;

    //    蘑菇敌人的构造函数
        public Enemy(int x, int y, boolean face_to, int type, BackGround bg) {
            this.x = x;
            this.y = y;
            this.face_to = face_to;
            this.type = type;
            this.bg = bg;
            show = StaticValue.mogu.get(0);
            thread.start();
        }

        //    食人花敌人的构造函数
        public Enemy(int x, int y, boolean face_to, int type, int max_up, int max_down, BackGround bg) {
            this.x = x;
            this.y = y;
            this.face_to = face_to;
            this.type = type;
            this.max_down = max_down;
            this.max_up = max_up;
            this.bg = bg;
            show = StaticValue.flower.get(0);
            thread.start();
        }
        //光束的构造函数
        public Enemy(int x, int y, boolean face_to, int type, BackGround bg,int time_to,boolean vanish) {
            this.x = x;
            this.y = y;
            this.face_to = face_to;
            this.type = type;
            this.bg = bg;
            this.time_to = time_to;
            this.vanish = vanish;
            show = StaticValue.light.get(0);
            thread.start();
        }

    //     死亡方法
    public void death() {
        show = StaticValue.mogu.get(2);
        this.bg.getEnemyList().remove(this);
    }


    @Override
    public void run() {
        while (true) {
//            判断是否为蘑菇敌人
            if (type == 1) {
                if (face_to) {
                    this.x -= 2;
                } else {
                    this.x += 2;
                }
                image_type = image_type == 1 ? 0 : 1;
                show = StaticValue.mogu.get(image_type);
            }
            //            判断是否为蘑菇敌人
            if (type == 3) {
                if (face_to) {
                    this.x -= 3;
                } else {
                    this.x += 3;
                }
                image_type = image_type == 1 ? 0 : 1;
                show = StaticValue.bird.get(image_type);
            }
            if (type == 4) {
                if (face_to) {
                    this.x -= 4;
                } else {
                    this.x += 4;
                }
                image_type = image_type == 1 ? 0 : 1;
                show = StaticValue.fire.get(image_type);
            }
//            定义两个布尔变量
            boolean canLeft = true;
            boolean canRight = true;

                for (int i = 0; i < bg.getObstacleList().size(); i++) {
                    Obstacle ob1 = bg.getObstacleList().get(i);
                    if (type == 3) {
                        //判断是否可以向右走
                        if (ob1.getX() == this.x + 40 && (ob1.getY() + 20 > this.y && ob1.getY() - 4 < this.y)) {
                            canRight = false;
                        }

    //                判断是否可以向左走
                        if (ob1.getX() == this.x - 20 && (ob1.getY() + 20 > this.y && ob1.getY() - 4 < this.y)) {
                            canLeft = false;
                        }
                    } else if (type == 4) {
                        //判断是否可以向右走
                        if (ob1.getX() == this.x + 30 && (ob1.getY() + 20 > this.y && ob1.getY() - 4 < this.y)) {
                            canRight = false;
                        }

    //                判断是否可以向左走
                        if (ob1.getX() == this.x - 10 && (ob1.getY() + 20 > this.y && ob1.getY() - 4 < this.y)) {
                            canLeft = false;
                        }
                    } else {
                        //判断是否可以向右走
                        if (ob1.getX() == this.x + 36 && (ob1.getY() + 65 > this.y && ob1.getY() - 35 < this.y)) {
                            canRight = false;
                        }

    //                判断是否可以向左走
                        if (ob1.getX() == this.x - 36 && (ob1.getY() + 65 > this.y && ob1.getY() - 35 < this.y)) {
                            canLeft = false;
                        }
                    }
                }
            if (face_to && !canLeft || this.x == 0) {
                face_to = false;
            } else if ((!face_to) && (!canRight) || this.x == 764) {
                face_to = true;
            }
//            判断是否为食人花敌人
            if (type == 2) {
                if (face_to) {
                    this.y -= 2;
                } else {
                    this.y += 2;
                }
                image_type = image_type == 1 ? 0 : 1;

//                判断食人花是否到达极限位置
                if (face_to && (this.y == max_up)) {
                    face_to = false;
                }
                if ((!face_to) && (this.y == max_down)) {
                    face_to = true;
                }
                show = StaticValue.flower.get(image_type);
            }

            if(type == 5){
                  if(vanish){
                      this.time_to -= 20;
                  }else{
                      this.time_to += 20;
                  }

                  if(vanish && (this.time_to == 0)){
                      vanish = false;
                      image_type = 0;
                  }
                  if(!vanish && (this.time_to == 800)){
                      vanish = true;
                      image_type = 1;
                  }
                show = StaticValue.light.get(image_type);
            }
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    public BufferedImage getShow() {
        return show;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getType() {
        return type;
    }

    public boolean isVanish() {

        return vanish;
    }
}
