//我们保证独立完成了整个程序从分析、设计到编码的所有工作。
//本段代码编写<202131773423-罗皓博>

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class StaticValue {
    //说明
    public  static BufferedImage introduce = null;
    //开始界面
    public static BufferedImage start = null;
    public static BufferedImage start2 = null;
    //    背景
    public static BufferedImage bg = null;
    public static BufferedImage bg3 = null;
    public static BufferedImage bg2 = null;
    public static BufferedImage bg4 = null;
    //    向左跳
    public static BufferedImage jump_L = null;
    public static BufferedImage jump_L2 = null;
    //    向右跳
    public static BufferedImage jump_R = null;
    public static BufferedImage jump_R2 = null;
    //    向左站立
    public static BufferedImage stand_L = null;
    public static BufferedImage stand_L2 = null;
    //    向右站立
    public static BufferedImage stand_R = null;
    public static BufferedImage stand_R2 = null;

    //    城堡
    public static BufferedImage tower = null;
    //    旗杆
    public static BufferedImage gan = null;
    //    障碍物
    public static List<BufferedImage> obstacle = new ArrayList<>();
    //    马里奥向左跑
    public static List<BufferedImage> run_L = new ArrayList<>();
    public static List<BufferedImage> run_L2 = new ArrayList<>();
    //    马里奥向右跑
    public static List<BufferedImage> run_R = new ArrayList<>();
    public static List<BufferedImage> run_R2 = new ArrayList<>();
    //    蘑菇敌人
    public static List<BufferedImage> mogu = new ArrayList<>();
    //    食人花敌人
    public static List<BufferedImage> flower = new ArrayList<>();
    //乌龟敌人
    public static List<BufferedImage> bird = new ArrayList<>();
    //火球敌人
    public static List<BufferedImage> fire = new ArrayList<>();
    //激光敌人
    public static List<BufferedImage> light = new ArrayList<>();
//
    //    路径的前缀，方便后续使用
    public static String path = System.getProperty("user.dir") + "/src/images/";
    InputStream io1 = this.getClass().getResourceAsStream("/images/introduce.png");
    InputStream io2 = this.getClass().getResourceAsStream("/images/start.png");
    InputStream io100 = this.getClass().getResourceAsStream("/images/start2.png");
    InputStream io3 = this.getClass().getResourceAsStream("/images/beijing3.png");
    InputStream io4 = this.getClass().getResourceAsStream("/images/beijing1.png");
    InputStream io5 = this.getClass().getResourceAsStream("/images/beijing2.png");
    InputStream io6 = this.getClass().getResourceAsStream("/images/beijing4.png");
    InputStream io7 = this.getClass().getResourceAsStream("/images/weiba_stand_L.png");
    InputStream io8 = this.getClass().getResourceAsStream("/images/weiba_stand_R.png");
    InputStream io9 = this.getClass().getResourceAsStream("/images/tower.png");
    InputStream io10 = this.getClass().getResourceAsStream("/images/gan.png");
    InputStream io11 = this.getClass().getResourceAsStream("/images/weiba_jump_L.png");
    InputStream io12 = this.getClass().getResourceAsStream("/images/weiba_jump_R.png");
    InputStream A1 = this.getClass().getResourceAsStream("/images/weiba_run_L_1.png");
    InputStream A2 = this.getClass().getResourceAsStream("/images/weiba_run_L_2.png");
    InputStream A3 = this.getClass().getResourceAsStream("/images/weiba_run_L_3.png");
    InputStream B1 = this.getClass().getResourceAsStream("/images/weiba_run_R_1.png");
    InputStream B2 = this.getClass().getResourceAsStream("/images/weiba_run_R_2.png");
    InputStream B3 = this.getClass().getResourceAsStream("/images/weiba_run_R_3.png");
    InputStream io13 = this.getClass().getResourceAsStream("/images/zhuan1.png");
    InputStream io14 = this.getClass().getResourceAsStream("/images/di4.png");
    InputStream io15 = this.getClass().getResourceAsStream("/images/di5.png");
    InputStream c1 = this.getClass().getResourceAsStream("/images/pipe1.png");
    InputStream c2 = this.getClass().getResourceAsStream("/images/pipe2.png");
    InputStream c3 = this.getClass().getResourceAsStream("/images/pipe3.png");
    InputStream c4 = this.getClass().getResourceAsStream("/images/pipe4.png");
    InputStream io16 = this.getClass().getResourceAsStream("/images/qiang2.png");
    InputStream io17 = this.getClass().getResourceAsStream("/images/flag.png");
    InputStream d1 = this.getClass().getResourceAsStream("/images/pangxie1.png");
    InputStream d2 = this.getClass().getResourceAsStream("/images/pangxie2.png");
    InputStream io18 = this.getClass().getResourceAsStream("/images/pangxie3.jpg");
    InputStream e1 = this.getClass().getResourceAsStream("/images/flower1.1.png");
    InputStream e2 = this.getClass().getResourceAsStream("/images/flower1.2.png");
    InputStream f1 = this.getClass().getResourceAsStream("/images/bird1.png");
    InputStream f2 = this.getClass().getResourceAsStream("/images/bird2.png");
    InputStream g1 = this.getClass().getResourceAsStream("/images/huo1.png");
    InputStream g2 = this.getClass().getResourceAsStream("/images/huo2.png");
    InputStream h1 = this.getClass().getResourceAsStream("/images/jiguang1.png");
    InputStream h2 = this.getClass().getResourceAsStream("/images/jiguang2.png");
    InputStream io19 = this.getClass().getResourceAsStream("/images/qingwa_stand_L.png");
    InputStream io20 = this.getClass().getResourceAsStream("/images/qingwa_stand_R.png");
    InputStream io21 = this.getClass().getResourceAsStream("/images/qingwa_jump_L.png");
    InputStream io22 = this.getClass().getResourceAsStream("/images/qingwa_jump_R.png");
    InputStream i1 = this.getClass().getResourceAsStream("/images/qingwa_run_L_1.png");
    InputStream i2 = this.getClass().getResourceAsStream("/images/qingwa_run_L_2.png");
    InputStream j1 = this.getClass().getResourceAsStream("/images/qingwa_run_R_1.png");
    InputStream j2 = this.getClass().getResourceAsStream("/images/qingwa_run_R_2.png");

    //    初始化方法
    public  void init() {
        try {
            //说明界面
            introduce =ImageIO.read(io1);
            //开始界面
            start = ImageIO.read(io2);
            start2 = ImageIO.read(io100);
            //        加载背景图片
            bg3 = ImageIO.read(io3);
            bg = ImageIO.read(io4);
            bg2 = ImageIO.read(io5);
            bg4 = ImageIO.read(io6);
//            向左站立
            stand_L = ImageIO.read(io7);
            stand_L2 = ImageIO.read(io19);

            //            向右站立
            stand_R = ImageIO.read(io8);
            stand_R2 = ImageIO.read(io20);
//            加载城堡
            tower = ImageIO.read(io9);
//            加载旗杆
            gan = ImageIO.read(io10);
//            加载向左跳跃
            jump_L = ImageIO.read(io11);
            jump_L2 = ImageIO.read(io21);
//            加载向右跳跃
            jump_R = ImageIO.read(io12);
            jump_R2 = ImageIO.read(io22);
        } catch (IOException e) {
            e.printStackTrace();
        }
//        向左跑
        for (int i = 1; i <= 3; i++) {
            try {
                if (i == 1) {
                    run_L.add(ImageIO.read(A1));
                } else if(i == 2) {
                    run_L.add(ImageIO.read(A2));
                }else{
                    run_L.add(ImageIO.read(A3));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        for (int i = 1; i <= 2; i++) {
            try {
                if (i == 1) {
                    run_L2.add(ImageIO.read(i1));
                } else if(i == 2) {
                    run_L2.add(ImageIO.read(i2));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
//        向右跑
        for (int i = 1; i <= 3; i++) {
            try {
                if (i == 1) {
                    run_R.add(ImageIO.read(B1));
                } else if(i == 2) {
                    run_R.add(ImageIO.read(B2));
                }else{
                    run_R.add(ImageIO.read(B3));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        //        向右跑
        for (int i = 1; i <= 3; i++) {
            try {
                if (i == 1) {
                    run_R2.add(ImageIO.read(j1));
                } else if(i == 2) {
                    run_R2.add(ImageIO.read(j2));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
//        加载障碍物
        try {
            obstacle.add(ImageIO.read(io13));
            obstacle.add(ImageIO.read(io14));
            obstacle.add(ImageIO.read(io15));
        } catch (IOException e) {
            e.printStackTrace();
        }
//        加载水管
        for (int i = 1; i <= 4; i++) {
            try {
                if (i == 1) {
                    obstacle.add(ImageIO.read(c1));
                } else if(i == 2) {
                    obstacle.add(ImageIO.read(c2));
                }else if(i == 3){
                    obstacle.add(ImageIO.read(c3));
                }else{
                    obstacle.add(ImageIO.read(c4));

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
//        加载不可破坏的砖块和旗子
        try {
            obstacle.add(ImageIO.read(io16));
            obstacle.add(ImageIO.read(io17));

        } catch (IOException e) {
            e.printStackTrace();
        }
//        加载蘑菇敌人
        for (int i = 1; i <= 3; i++) {
            try {
                if(i == 3){
                    mogu.add(ImageIO.read(io18));
                }else if( i == 1){
                    mogu.add(ImageIO.read(d1));
                }else{
                    mogu.add(ImageIO.read(d2));

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
//        加载食人花敌人
        for (int i = 1; i <= 2; i++) {
            try {
                if (i == 1) {
                    flower.add(ImageIO.read(e1));
                } else {
                    flower.add(ImageIO.read(e2));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        //加载鸟敌人
        for (int i = 1; i <= 2; i++){
            try {
                if (i == 1) {
                    bird.add(ImageIO.read(f1));
                } else {
                    bird.add(ImageIO.read(f2));

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        //加载火球敌人
        for (int i = 1; i <= 2; i++){
            try {
                if (i == 1) {
                    fire.add(ImageIO.read(g1));
                } else {
                    fire.add(ImageIO.read(g2));

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        for(int i = 1; i <= 2; i++){
            try {
                if (i == 1) {
                    light.add(ImageIO.read(h1));
                } else {
                    light.add(ImageIO.read(h2));

                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
