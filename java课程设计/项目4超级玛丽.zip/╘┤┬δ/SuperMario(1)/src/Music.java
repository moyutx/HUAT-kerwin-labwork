//我们保证独立完成了整个程序从分析、设计到编码的所有工作。
//本段代码编写<202131773419-况思鹏>


import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class Music {
    public  Music() throws FileNotFoundException, JavaLayerException {
        Player player;
        String str = System.getProperty("user.dir")+"/src/Music/music.wav";
        BufferedInputStream name = new BufferedInputStream(new   FileInputStream(str));
        player = new Player(name);
        player.play();
    }
}
